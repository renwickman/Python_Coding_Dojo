from django.apps import AppConfig


class FormAppConfig(AppConfig):
    name = 'form_app'
